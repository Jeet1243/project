package com.service;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.dbutil.DBUtil;
import com.model.Exam;


@Service
public class ExamService{
	
	
	static List<Exam> grelist = new ArrayList<>();
	
	
	static List<Exam> praxislist = new ArrayList<>();
	

	static List<Exam> toeiclist = new ArrayList<>();
	

	static List<Exam> toefllist = new ArrayList<>();
	
	
	Connection connection;
	
	public ExamService() throws SQLException {
		connection =  DBUtil.getConnection();
	}

	public List<Exam> getGreData(){

		try {
			PreparedStatement ps = connection.prepareStatement("select * from gre");
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				Exam obj = new Exam();
				obj.setExamID(rs.getInt(1));
				obj.setStudentName(rs.getString(2));
				obj.setAge(rs.getInt(3));
				obj.setExamDate(rs.getString(4));
				
				grelist.add(obj);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
		return grelist;
	}
	
	public List<Exam> getPraxisData(){

		try {
			PreparedStatement ps = connection.prepareStatement("select * from praxis");
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				Exam obj = new Exam();
				obj.setExamID(rs.getInt(1));
				obj.setStudentName(rs.getString(2));
				obj.setAge(rs.getInt(3));
				obj.setExamDate(rs.getString(4));
				
				praxislist.add(obj);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
		return praxislist;
	}
	
	public List<Exam> getToeicData(){

		try {
			PreparedStatement ps = connection.prepareStatement("select * from toeic");
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				Exam obj = new Exam();
				obj.setExamID(rs.getInt(1));
				obj.setStudentName(rs.getString(2));
				obj.setAge(rs.getInt(3));
				obj.setExamDate(rs.getString(4));
				
				toeiclist.add(obj);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
		return toeiclist;
	}
	
	public List<Exam> getToeflData(){

		try {
			PreparedStatement ps = connection.prepareStatement("select * from toefl");
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				Exam obj = new Exam();
				obj.setExamID(rs.getInt(1));
				obj.setStudentName(rs.getString(2));
				obj.setAge(rs.getInt(3));
				obj.setExamDate(rs.getString(4));
				
				toefllist.add(obj);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
		return toefllist;
	}

}
