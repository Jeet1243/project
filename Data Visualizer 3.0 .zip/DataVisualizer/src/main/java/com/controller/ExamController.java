package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.model.Exam;
import com.model.SelectedExam;
import com.service.ExamService;




@Controller
public class ExamController {

	@Autowired
	private ExamService service;
	
	
	@GetMapping("/viewOptions")
	public String getTableData() {
		return "dragDrop";
	}
	

	
	@GetMapping("/display")
	public String display(@RequestParam("selectedOptions") String selectedOptions, Model m) {
		
			System.out.println("Selection is " + selectedOptions);
			m.addAttribute("selectedOptions",selectedOptions);
			if(selectedOptions.equalsIgnoreCase("gre"))
			{
				m.addAttribute("object", service.getGreData());
			}
			else if(selectedOptions.equalsIgnoreCase("praxis"))
			{
				m.addAttribute("object", service.getPraxisData());
			}
			else if(selectedOptions.equalsIgnoreCase("toefl"))
			{
				m.addAttribute("object", service.getToeflData());
			}
			else if(selectedOptions.equalsIgnoreCase("toeic"))
			{
				m.addAttribute("object", service.getToeicData());
			}

		return "dashboard";
	}
}
