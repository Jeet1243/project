package com.model;

public class SelectedExam {
	
	private String selectedExamName;

	public SelectedExam() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public SelectedExam(String selectedExam) {
		super();
		this.selectedExamName = selectedExam;
	}


	public String getSelectedExam() {
		return selectedExamName;
	}

	public void setSelectedExam(String selectedExam) {
		this.selectedExamName = selectedExam;
	}
	
	

}
