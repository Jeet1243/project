package com.model;


public class Exam {
	private int examID;
	private String studentName;
	private int age;
	private String examDate;
	
	public int getExamID() {
		return examID;
	}
	public void setExamID(int examID) {
		this.examID = examID;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getExamDate() {
		return examDate;
	}
	public void setExamDate(String examDate) {
		this.examDate = examDate;
	}
	
	public Exam(int examID, String studentName, int age, String examDate) {
		super();
		this.examID = examID;
		this.studentName = studentName;
		this.age = age;
		this.examDate = examDate;
	}
	
	public Exam() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Model [examID=" + examID + ", studentName=" + studentName + ", age=" + age + ", examDate=" + examDate
				+ "]";
	}

}
