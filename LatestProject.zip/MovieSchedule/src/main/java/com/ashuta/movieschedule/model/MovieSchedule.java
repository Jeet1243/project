package com.ashuta.movieschedule.model;

import java.time.LocalDate;

import java.time.LocalTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonValueFormat;

import lombok.Data;

public class MovieSchedule {
	
	@org.springframework.data.annotation.Id
	private int id;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy")
	private LocalDate date;
	private String movieTitle;
	private LocalTime startsAt;
	private LocalTime endsAt;
	public MovieSchedule() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MovieSchedule(int id, LocalDate date, String movieTitle, LocalTime startsAt, LocalTime endsAt) {
		super();
		this.id = id;
		this.date = date;
		this.movieTitle = movieTitle;
		this.startsAt = startsAt;
		this.endsAt = endsAt;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getMovieTitle() {
		return movieTitle;
	}
	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}
	public LocalTime getStartsAt() {
		return startsAt;
	}
	public void setStartsAt(LocalTime startsAt) {
		this.startsAt = startsAt;
	}
	public LocalTime getEndsAt() {
		return endsAt;
	}
	public void setEndsAt(LocalTime endsAt) {
		this.endsAt = endsAt;
	}
	
	
	
	
	
	
}