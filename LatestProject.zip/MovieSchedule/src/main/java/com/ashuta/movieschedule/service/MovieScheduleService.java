package com.ashuta.movieschedule.service;

import java.time.LocalDate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.ashuta.movieschedule.dao.MovieRepository;
import com.ashuta.movieschedule.model.MovieSchedule;


@Service
public class MovieScheduleService {
	
    @Autowired
    private MovieRepository repository;
    

    public MovieSchedule saveMovieSchedule(MovieSchedule movieSchedule) {
        return repository.save(movieSchedule);
    }

    public String deleteMovieSchedule(int id) {
        repository.deleteById(id);
        return "schedule removed for id:" + id;
    }

    public MovieSchedule updateMovieSchedule(MovieSchedule movieSchedule) {
        MovieSchedule existingMovie = repository.findByDate(movieSchedule.getDate());
        existingMovie.setStartsAt(movieSchedule.getStartsAt());
        existingMovie.setEndsAt(movieSchedule.getEndsAt());
        return repository.save(movieSchedule);
    }

	public List<MovieSchedule> getMovies(LocalDate date) {
		return repository.findAllMoviesByDate(date);
	}
	
	
	
	
	public List<MovieSchedule> getAllMovieSchedule() {
		return repository.findAll();
	}

	
	public List<MovieSchedule> findAllByMovieTitle(String movie) {
		// TODO Auto-generated method stub
//		Query query = new Query(Criteria.where("movieTitle").is(movie)) ;
//		return repository.find(query,MovieSchedule.class);
		return repository.findAllByMovieTitle(movie);
	}

}
