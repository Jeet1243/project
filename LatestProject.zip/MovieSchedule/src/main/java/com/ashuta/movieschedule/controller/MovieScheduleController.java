package com.ashuta.movieschedule.controller;

import java.time.LocalDate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ashuta.movieschedule.model.MovieSchedule;
import com.ashuta.movieschedule.service.MovieScheduleService;

@RestController
@RequestMapping("/schedule")
public class MovieScheduleController {

    @Autowired
    private MovieScheduleService service;
    
    @GetMapping("/movies")
    public List<MovieSchedule> findAllMovieSchedule() {
        return service.getAllMovieSchedule();
    }

    @PostMapping("/addMovieSchedule")
    public MovieSchedule addMovieSchedule(@RequestBody MovieSchedule movieSchedule) {
        return service.saveMovieSchedule(movieSchedule);
    }

    @GetMapping("/moviesForDate/{date}")
    public List<MovieSchedule> findAllMoviesByDate(@PathVariable @DateTimeFormat(pattern="dd-MM-yyyy") LocalDate date) {
        return service.getMovies(date);
    }
    
    @GetMapping("/moviesByTitle/{movie}")
    public List<MovieSchedule> findAllMoviesByMovieTitle(@PathVariable String movie) {
        return service.findAllByMovieTitle(movie);
    }

    @PutMapping("/update/{date}")
    public MovieSchedule updateMovieSchedule(@RequestBody @DateTimeFormat(pattern="dd-MM-yyyy") MovieSchedule movieSchedule) {
        return service.updateMovieSchedule(movieSchedule);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteEmployee(@PathVariable int id) {
        return service.deleteMovieSchedule(id);
    }
}

