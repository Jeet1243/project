package com.ashuta.movieschedule.dao;

import java.time.LocalDate;
import java.util.List;

import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.ashuta.movieschedule.model.MovieSchedule;

@Repository
public interface MovieRepository extends MongoRepository<MovieSchedule,Integer> {

	
	

	List<MovieSchedule> findAllMoviesByDate(LocalDate date);

	MovieSchedule findByDate(LocalDate date);

//	List<MovieSchedule> findByMovieTitle(String movieTitle, Pageable pageable);
	
	@Query("{ 'movieTitle' : ?0 }")
	List<MovieSchedule> findAllByMovieTitle(String movieTitle);

}
