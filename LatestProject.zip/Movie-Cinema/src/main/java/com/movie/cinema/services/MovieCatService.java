package com.movie.cinema.services;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.movie.cinema.moviedetails.Movie;
import com.movie.cinema.moviedetails.MovieSchedule;
import com.movie.cinema.moviedetails.MovieWithSchedule;
import com.movie.cinema.repo.MovieRepository;

@Service
public class MovieCatService {
	
	@Autowired
	MovieRepository movieRepo;
//	
	// Add 
		public Movie addMovie(Movie movie) {
		    return movieRepo.save(movie);
		}
		
		
		// READ All Movies
		public List<Movie> getAllMovies() {
		    return movieRepo.findAll();
		}
		
		
		// Get movie by title
	    public Movie getMovieByTitle(String title) {
	        return movieRepo.findByMovieTitle(title);
	    }
		
		
	 // Delete movie by title
	    public void deleteMovie(String title) {
	        movieRepo.deleteByMovieTitle(title);
	    }
	    
	    
	 // Update movie by title
	    public Movie updateMovie(String title, Movie movie) {
	        Movie movieToUpdate = movieRepo.findByMovieTitle(title);
	        movieToUpdate.setMovieTitle(movie.getMovieTitle());
	        movieToUpdate.setDescription(movie.getDescription());
	        movieToUpdate.setGenre(movie.getGenre());
	        movieToUpdate.setImdbRating(movie.getImdbRating());
	        return movieRepo.save(movieToUpdate);
	    }

	    @Autowired
	    private RestTemplate restTemplate;
	    

		public MovieWithSchedule getMovieWithSchedulesByTitle(String title) {
			// TODO Auto-generated method stub
			
			MovieWithSchedule movieWithSchedule = new MovieWithSchedule();
			
			Movie movie = movieRepo.findByMovieTitle(title);
			
			
			MovieSchedule[] response = restTemplate.getForObject("http://localhost:8051/schedule/moviesByTitle/"+title, MovieSchedule[].class);
			
			List<MovieSchedule> movieSchedule = Arrays.asList(response);
					
			
			movieWithSchedule.setMovie(movie);
			movieWithSchedule.setMovieSchedule(movieSchedule);
			
			return movieWithSchedule;
		}
		
		
		
		
		
		
		
		
		
		
	

}
