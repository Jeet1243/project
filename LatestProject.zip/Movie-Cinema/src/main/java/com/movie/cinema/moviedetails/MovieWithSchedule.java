package com.movie.cinema.moviedetails;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MovieWithSchedule {
	
	private Movie movie;
	private List<MovieSchedule> movieSchedule;
	
	
	
	public MovieWithSchedule() {
		movieSchedule = new ArrayList<>();

		// TODO Auto-generated constructor stub
	}



	public MovieWithSchedule(Movie movie, List<MovieSchedule> movieSchedule) {
		super();
		this.movie = movie;
		this.movieSchedule = movieSchedule;
	}



	public Movie getMovie() {
		return movie;
	}



	public void setMovie(Movie movie) {
		this.movie = movie;
	}



	public List<MovieSchedule> getMovieSchedule() {
		return movieSchedule;
	}



	public void setMovieSchedule(List<MovieSchedule> movieSchedule) {
		this.movieSchedule = movieSchedule;
	}
	
	


	


	
	

}
