package com.movie.cinema.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.movie.cinema.moviedetails.Movie;
import com.movie.cinema.moviedetails.MovieWithSchedule;
import com.movie.cinema.services.MovieCatService;

@RestController
@RequestMapping("/movies")
public class MovieCatalogueController {

    @Autowired
    private MovieCatService movieCatService;

    // View
    @GetMapping("/")
    public List<Movie> getAllMovies() {
        return movieCatService.getAllMovies();
    }

    // Search movie
    @GetMapping("/{title}")
    public Movie getMovieByTitle(@PathVariable("title") String title) {
        return movieCatService.getMovieByTitle(title);
    }

    // Add movie details
    @PostMapping("/")
    public Movie addMovie(@RequestBody Movie movie) {
        return movieCatService.addMovie(movie);
    }

    // Update movie
    @PutMapping("/{title}")
    public Movie updateMovie(@PathVariable("title") String title, @RequestBody Movie movie) {
        return movieCatService.updateMovie(title, movie);
    }

    // Delete movie details
    @DeleteMapping("/{title}")
    public void deleteMovie(@PathVariable("title") String title) {
    	movieCatService.deleteMovie(title);
    }
    
    
    @GetMapping("/schedule/{title}")
    public MovieWithSchedule getMovieWithSchedulesByTitle(@PathVariable("title") String title) {
        return movieCatService.getMovieWithSchedulesByTitle(title);
    }
    
    
}
