package com.movie.cinema.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.movie.cinema.moviedetails.Movie;

public interface MovieRepository extends MongoRepository<Movie,Integer> {
	void deleteByMovieTitle(String title);
    Movie findByMovieTitle(String title);
}
