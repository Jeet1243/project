package com.movie.cinema.moviedetails;

public class Movie {
	
	private Long movieId;
	private String movieTitle;
	private String description;
	private String genre;
	private double imdbRating;

	public Movie() {
		super();

	}
	public Movie(Long movieId, String movieTitle, String description, String genre, double imdbRating) {
		super();
		this.movieId = movieId;
		this.movieTitle = movieTitle;
		this.description = description;
		this.genre = genre;
		this.imdbRating = imdbRating;
	}
	
	public Long getMovieId() {
		return movieId;
	}
	public void setMovieId(Long id) {
		this.movieId = id;
	}
	public String getMovieTitle() {
		return movieTitle;
	}
	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public double getImdbRating() {
		return imdbRating;
	}
	public void setImdbRating(double imdbRating) {
		this.imdbRating = imdbRating;
	}
	@Override
	public String toString() {
		return "MovieDetails [movieId=" + movieId + ", movieTitle=" + movieTitle + ", description=" + description
				+ ", genre=" + genre + ", imdbRating=" + imdbRating + "]";
	}
	
	
	
	
	

	
	


}
