package com.movie.cinema.moviedetails;

import java.time.LocalDate;

import java.time.LocalTime;

import com.fasterxml.jackson.annotation.JsonFormat;

public class MovieSchedule {
	
//	@org.springframework.data.annotation.Id
	private int id;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy")
	private LocalDate date;
	private LocalTime startsAt;
	private LocalTime endsAt;
	
	public MovieSchedule(int id, LocalDate date, LocalTime startsAt, LocalTime endsAt) {
		super();
		this.id = id;
		this.date = date;
		this.startsAt = startsAt;
		this.endsAt = endsAt;
	}
	
	public MovieSchedule() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public LocalTime getStartsAt() {
		return startsAt;
	}
	public void setStartsAt(LocalTime startsAt) {
		this.startsAt = startsAt;
	}
	public LocalTime getEndsAt() {
		return endsAt;
	}
	public void setEndsAt(LocalTime endsAt) {
		this.endsAt = endsAt;
	}

}
